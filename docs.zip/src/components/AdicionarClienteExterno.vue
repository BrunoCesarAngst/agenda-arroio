<template>
  <form @submit.prevent="handleSubmit" class="space-y-4">
    <div>
      <label class="block text-sm">Nome do cliente</label>
      <input v-model="nome" required class="input" placeholder="Nome completo" />
    </div>
    <div>
      <label class="block text-sm">Telefone</label>
      <input v-model="telefone" class="input" placeholder="(51) 99999-9999" />
    </div>
    <div>
      <label class="block text-sm">E-mail (opcional)</label>
      <input v-model="email" class="input" type="email" placeholder="cliente@email.com" />
    </div>
    <button :disabled="loading" class="btn-primary w-full">
      {{ loading ? 'Salvando...' : 'Cadastrar cliente' }}
    </button>
    <p v-if="erro" class="text-red-500 text-sm">{{ erro }}</p>
    <p v-if="sucesso" class="text-green-600 text-sm">{{ sucesso }}</p>
  </form>
</template>

<script setup>
import { addDoc, collection, getDocs, query, serverTimestamp, where } from 'firebase/firestore'
import { ref } from 'vue'
import { db } from '../services/firebase'

const nome = ref('')
const telefone = ref('')
const email = ref('')
const loading = ref(false)
const erro = ref('')
const sucesso = ref('')

const handleSubmit = async () => {
  loading.value = true
  erro.value = ''
  sucesso.value = ''

  try {
    // Checar duplicidade pelo telefone
    if (telefone.value) {
      const q = query(
        collection(db, 'usuarios'),
        where('telefone', '==', telefone.value)
      )
      const res = await getDocs(q)
      if (!res.empty) {
        erro.value = 'Já existe um cliente com este telefone.'
        loading.value = false
        return
      }
    }

    // Criar usuário
    const novoCliente = {
      nome: nome.value,
      telefone: telefone.value || '',
      email: email.value || '',
      tipo: 'cliente_externo',
      ativo: true,
      criadoEm: serverTimestamp()
    }
    // Log do objeto enviado
    console.log('Enviando para Firestore:', novoCliente)

    await addDoc(collection(db, 'usuarios'), novoCliente)
    sucesso.value = 'Cliente cadastrado com sucesso!'
    nome.value = telefone.value = email.value = ''
  } catch (e) {
    erro.value = 'Erro ao salvar: ' + (e.message || e) + '\nObjeto enviado: ' + JSON.stringify({
      nome: nome.value,
      telefone: telefone.value || '',
      email: email.value || '',
      tipo: 'cliente_externo',
      ativo: true,
      criadoEm: 'serverTimestamp()'
    }, null, 2)
  }
  loading.value = false
}
</script>

<style scoped>
.input {
  @apply mt-1 w-full border rounded p-2 shadow focus:ring focus:ring-blue-300;
}
.btn-primary {
  @apply bg-blue-600 text-white rounded p-2 hover:bg-blue-700;
}
</style>