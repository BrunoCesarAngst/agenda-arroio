<template>
  <router-view />
  <DevTools />
</template>

<script setup>
import DevTools from './components/DevTools.vue';
</script>
