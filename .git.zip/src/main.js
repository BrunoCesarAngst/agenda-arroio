import { inject } from '@vercel/analytics';
import { createApp } from 'vue';
import { VueFire, VueFireAuth } from 'vuefire';
import App from './App.vue';
import router from './router/index';
import { app } from './services/firebase';
import './style.css';

inject()

const vueApp = createApp(App)
vueApp.use(router)
vueApp.use(VueFire, {
  firebaseApp: app,
  modules: [
    VueFireAuth(),
  ],
})
vueApp.mount('#app')
